
Demonstration of how to convert and play wav sample files

Included wav audio files are in the public domain

Conversion of samples:
  - `utils/cvtsamplesms.py sndrec/cowbell_8bit_pcm_unsigned.wav
  - `utils/cvtsamplesms.py sndrec/risset_drum_8bit_pcm_unsigned.wav

