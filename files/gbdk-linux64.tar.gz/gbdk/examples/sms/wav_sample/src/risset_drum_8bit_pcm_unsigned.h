#ifndef __risset_drum_8bit_pcm_unsigned_INCLUDE__
#define __risset_drum_8bit_pcm_unsigned_INCLUDE__

#include <gbdk/platform.h>
#include <stdint.h>

BANKREF_EXTERN(risset_drum_8bit_pcm_unsigned)
extern const uint8_t risset_drum_8bit_pcm_unsigned[3600];
#endif
