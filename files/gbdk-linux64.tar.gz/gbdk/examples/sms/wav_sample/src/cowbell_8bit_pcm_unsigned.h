#ifndef __cowbell_8bit_pcm_unsigned_INCLUDE__
#define __cowbell_8bit_pcm_unsigned_INCLUDE__

#include <gbdk/platform.h>
#include <stdint.h>

BANKREF_EXTERN(cowbell_8bit_pcm_unsigned)
extern const uint8_t cowbell_8bit_pcm_unsigned[8064];
#endif
