#ifndef SAMPLES_BANK3_H_INCLUDE
#define SAMPLES_BANK3_H_INCLUDE

#include <gbdk/platform.h>

void play_sample2(void) BANKED;

#endif