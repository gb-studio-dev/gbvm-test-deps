#ifndef SAMPLES_BANK2_H_INCLUDE
#define SAMPLES_BANK2_H_INCLUDE

#include <gbdk/platform.h>

void play_sample1(void) BANKED;

#endif